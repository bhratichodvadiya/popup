import 'dart:ui';

class AppColor {
  static Color primary = Color(0xffDAA520);
  static Color black300 = Color(0xff2A2A2A);
  static Color white = Color(0xffFFFFFF);
  static Color gray = Color(0xff707070);
  static Color orange = Color(0xffDA5820);
    static Color color2 = Color(0xFFFCE5AC);
}
